"""Daily paper-trading evaluation. No betting or fabricated predictions.
Supply a CSV of timestamped pre-race predictions to evaluate.
"""
import csv
import json
from datetime import datetime, timezone
from pathlib import Path

INPUT = Path('data/predictions.csv')
OUTPUT = Path('results/latest.json')
REQUIRED = {'race_id', 'prediction_time', 'race_time', 'probability', 'odds', 'won'}

def main():
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    report = {'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'awaiting_data', 'bets': 0, 'stake_yen': 0, 'returned_yen': 0, 'roi_percent': None}
    if INPUT.exists():
        with INPUT.open(encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            if not REQUIRED.issubset(reader.fieldnames or []):
                raise ValueError('CSV missing columns: ' + ', '.join(sorted(REQUIRED - set(reader.fieldnames or []))))
            bets = []
            for r in reader:
                p, odds, won = float(r['probability']), float(r['odds']), int(r['won'])
                pred, race = datetime.fromisoformat(r['prediction_time']), datetime.fromisoformat(r['race_time'])
                if not (0 <= p <= 1 and odds > 1 and won in (0, 1) and pred < race):
                    raise ValueError('Invalid probability/odds/won or prediction after race start')
                if p * odds > 1.05:
                    bets.append((r, odds, won))
            # One candidate per race: strongest modeled edge
            chosen = {}
            for r, odds, won in bets:
                key = r['race_id']
                edge = float(r['probability']) * odds
                if key not in chosen or edge > chosen[key][0]:
                    chosen[key] = (edge, odds, won)
            stake = len(chosen) * 100
            returned = sum(100 * odds * won for _, odds, won in chosen.values())
            report.update(status='evaluated', bets=len(chosen), stake_yen=stake, returned_yen=returned, roi_percent=round(returned / stake * 100, 2) if stake else None)
    OUTPUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
