GitHub Actions automatic evaluation (starter)

1. Upload daily.py to repository root.
2. Upload daily.yml to .github/workflows/daily.yml.
3. GitHub > Actions > Daily boat-racing paper-trade evaluation > Run workflow.
4. Read results/latest.json for outcome. Workflow also runs daily at about 10:20 JST.

IMPORTANT: This is a working scheduled evaluation skeleton, NOT an AI prediction or live data collector. Without data/predictions.csv, it writes status awaiting_data. Never interpret test data as proof of profitability.

Input data/predictions.csv columns:
race_id,prediction_time,race_time,probability,odds,won
R1,2026-10-09T09:00:00,2026-10-09T10:00:00,0.4,3.0,1

Only use genuine predictions recorded before race start and odds actually available at that time. Never use post-race data to produce predictions. GitHub Actions scheduled runs may be delayed; workflow must be on default branch and Actions enabled.
